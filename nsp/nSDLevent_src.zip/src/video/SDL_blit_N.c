/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2012 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Sam Lantinga
    slouken@libsdl.org
*/
#include "SDL_config.h"

#include "SDL_video.h"
#include "SDL_endian.h"
#include "SDL_cpuinfo.h"
#include "SDL_blit.h"

/* Functions to blit from N-bit surfaces to other surfaces */

#if SDL_ALTIVEC_BLITTERS
#if __MWERKS__
#pragma altivec_model on
#endif
#ifdef HAVE_ALTIVEC_H
#include <altivec.h>
#endif
#define assert(X)
#ifdef __MACOSX__
#include <sys/sysctl.h>
static size_t GetL3CacheSize( void )
{
    const char key[] = "hw.l3cachesize";
    u_int64_t result = 0;
    size_t typeSize = sizeof( result );


    int err = sysctlbyname( key, &result, &typeSize, NULL, 0 );
    if( 0 != err ) return 0;

    return result;
}
#else
static size_t GetL3CacheSize( void )
{
    /* XXX: Just guess G4 */
    return 2097152;
}
#endif /* __MACOSX__ */

#if (defined(__MACOSX__) && (__GNUC__ < 4))
    #define VECUINT8_LITERAL(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p) \
        (vector unsigned char) ( a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p )
    #define VECUINT16_LITERAL(a,b,c,d,e,f,g,h) \
        (vector unsigned short) ( a,b,c,d,e,f,g,h )
#else
    #define VECUINT8_LITERAL(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p) \
        (vector unsigned char) { a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p }
    #define VECUINT16_LITERAL(a,b,c,d,e,f,g,h) \
        (vector unsigned short) { a,b,c,d,e,f,g,h }
#endif

#define UNALIGNED_PTR(x) (((size_t) x) & 0x0000000F)
#define VSWIZZLE32(a,b,c,d) (vector unsigned char) \
                               ( 0x00+a, 0x00+b, 0x00+c, 0x00+d, \
                                 0x04+a, 0x04+b, 0x04+c, 0x04+d, \
                                 0x08+a, 0x08+b, 0x08+c, 0x08+d, \
                                 0x0C+a, 0x0C+b, 0x0C+c, 0x0C+d )

#define MAKE8888(dstfmt, r, g, b, a)  \
    ( ((r<<dstfmt->Rshift)&dstfmt->Rmask) | \
      ((g<<dstfmt->Gshift)&dstfmt->Gmask) | \
      ((b<<dstfmt->Bshift)&dstfmt->Bmask) | \
      ((a<<dstfmt->Ashift)&dstfmt->Amask) )

/*
 * Data Stream Touch...Altivec cache prefetching.
 *
 *  Don't use this on a G5...however, the speed boost is very significant
 *   on a G4.
 */
#define DST_CHAN_SRC 1
#define DST_CHAN_DEST 2

/* macro to set DST control word value... */
#define DST_CTRL(size, count, stride) \
    (((size) << 24) | ((count) << 16) | (stride))

#define VEC_ALIGNER(src) ((UNALIGNED_PTR(src)) \
    ? vec_lvsl(0, src) \
    : vec_add(vec_lvsl(8, src), vec_splat_u8(8)))


static Uint32 GetBlitFeatures( void )
{
    static Uint32 features = 0xffffffff;
    if (features == 0xffffffff) {
        /* Provide an override for testing .. */
        char *override = SDL_getenv("SDL_ALTIVEC_BLIT_FEATURES");
        if (override) {
            features = 0;
            SDL_sscanf(override, "%u", &features);
        } else {
            features = ( 0
                /* Feature 1 is has-MMX */
                | ((SDL_HasMMX()) ? 1 : 0)
                /* Feature 2 is has-AltiVec */
                | ((SDL_HasAltiVec()) ? 2 : 0)
                /* Feature 4 is dont-use-prefetch */
                /* !!!! FIXME: Check for G5 or later, not the cache size! Always prefetch on a G4. */
                | ((GetL3CacheSize() == 0) ? 4 : 0)
            );
        }
    }
    return features;
}
#if __MWERKS__
#pragma altivec_model off
#endif
#else
/* Feature 1 is has-MMX */
#define GetBlitFeatures() ((Uint32)(SDL_HasMMX() ? 1 : 0))
#endif

/* This is now endian dependent */
#if SDL_BYTEORDER == SDL_LIL_ENDIAN
#define HI	1
#define LO	0
#else /* SDL_BYTEORDER == SDL_BIG_ENDIAN */
#define HI	0
#define LO	1
#endif


static void Blit_RGB565_ARGB8888(SDL_BlitInfo *info)
{
}

static void Blit_RGB565_ABGR8888(SDL_BlitInfo *info)
{
}
static void Blit_RGB565_RGBA8888(SDL_BlitInfo *info)
{
}

/* Special optimized blit for RGB 5-6-5 --> BGRA 8-8-8-8 */
static void Blit_RGB565_BGRA8888(SDL_BlitInfo *info)
{
}

/* Special optimized blit for RGB 8-8-8 --> RGB 3-3-2 */
#ifndef RGB888_RGB332
#define RGB888_RGB332(dst, src) { \
	dst = (((src)&0x00E00000)>>16)| \
	      (((src)&0x0000E000)>>11)| \
	      (((src)&0x000000C0)>>6); \
}
#endif
static void Blit_RGB888_index8_map(SDL_BlitInfo *info)
{
}
static void BlitNto1(SDL_BlitInfo *info)
{
#ifndef USE_DUFFS_LOOP
	int c;
#endif
	int width, height;
	Uint8 *src;
	const Uint8 *map;
	Uint8 *dst;
	int srcskip, dstskip;
	int srcbpp;
	Uint32 Pixel;
	int  sR, sG, sB;
	SDL_PixelFormat *srcfmt;

	/* Set up some basic variables */
	width = info->d_width;
	height = info->d_height;
	src = info->s_pixels;
	srcskip = info->s_skip;
	dst = info->d_pixels;
	dstskip = info->d_skip;
	map = info->table;
	srcfmt = info->src;
	srcbpp = srcfmt->BytesPerPixel;

	if ( map == NULL ) {
		while ( height-- ) {
#ifdef USE_DUFFS_LOOP
			DUFFS_LOOP(
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( 1 ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = ((sR>>5)<<(3+2))|
					        ((sG>>5)<<(2)) |
					        ((sB>>6)<<(0)) ;
				}
				dst++;
				src += srcbpp;
			, width);
#else
			for ( c=width; c; --c ) {
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( 1 ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = ((sR>>5)<<(3+2))|
					        ((sG>>5)<<(2)) |
					        ((sB>>6)<<(0)) ;
				}
				dst++;
				src += srcbpp;
			}
#endif
			src += srcskip;
			dst += dstskip;
		}
	} else {
		while ( height-- ) {
#ifdef USE_DUFFS_LOOP
			DUFFS_LOOP(
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( 1 ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = map[((sR>>5)<<(3+2))|
						   ((sG>>5)<<(2))  |
						   ((sB>>6)<<(0))  ];
				}
				dst++;
				src += srcbpp;
			, width);
#else
			for ( c=width; c; --c ) {
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( 1 ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = map[((sR>>5)<<(3+2))|
						   ((sG>>5)<<(2))  |
						   ((sB>>6)<<(0))  ];
				}
				dst++;
				src += srcbpp;
			}
#endif /* USE_DUFFS_LOOP */
			src += srcskip;
			dst += dstskip;
		}
	}
}

static void BlitNtoN(SDL_BlitInfo *info)
{
	int width = info->d_width;
	int height = info->d_height;
	Uint8 *src = info->s_pixels;
	int srcskip = info->s_skip;
	Uint8 *dst = info->d_pixels;
	int dstskip = info->d_skip;
	SDL_PixelFormat *srcfmt = info->src;
	int srcbpp = srcfmt->BytesPerPixel;
	SDL_PixelFormat *dstfmt = info->dst;
	int dstbpp = dstfmt->BytesPerPixel;
	unsigned alpha = dstfmt->Amask ? srcfmt->alpha : 0;

	while ( height-- ) {
		DUFFS_LOOP(
		{
		        Uint32 Pixel;
			unsigned sR;
			unsigned sG;
			unsigned sB;
			DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel, sR, sG, sB);
			ASSEMBLE_RGBA(dst, dstbpp, dstfmt, sR, sG, sB, alpha);
			dst += dstbpp;
			src += srcbpp;
		},
		width);
		src += srcskip;
		dst += dstskip;
	}
}

static void BlitNto1Key(SDL_BlitInfo *info)
{
	int width = info->d_width;
	int height = info->d_height;
	Uint8 *src = info->s_pixels;
	int srcskip = info->s_skip;
	Uint8 *dst = info->d_pixels;
	int dstskip = info->d_skip;
	SDL_PixelFormat *srcfmt = info->src;
	const Uint8 *palmap = info->table;
	Uint32 ckey = srcfmt->colorkey;
	Uint32 rgbmask = ~srcfmt->Amask;
	int srcbpp;
	Uint32 Pixel;
	unsigned sR, sG, sB;

	/* Set up some basic variables */
	srcbpp = srcfmt->BytesPerPixel;
	ckey &= rgbmask;

	if ( palmap == NULL ) {
		while ( height-- ) {
			DUFFS_LOOP(
			{
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( (Pixel & rgbmask) != ckey ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = (Uint8)(((sR>>5)<<(3+2))|
						           ((sG>>5)<<(2)) |
						           ((sB>>6)<<(0)));
				}
				dst++;
				src += srcbpp;
			},
			width);
			src += srcskip;
			dst += dstskip;
		}
	} else {
		while ( height-- ) {
			DUFFS_LOOP(
			{
				DISEMBLE_RGB(src, srcbpp, srcfmt, Pixel,
								sR, sG, sB);
				if ( (Pixel & rgbmask) != ckey ) {
				  	/* Pack RGB into 8bit pixel */
				  	*dst = (Uint8)palmap[((sR>>5)<<(3+2))|
							             ((sG>>5)<<(2))  |
							             ((sB>>6)<<(0))  ];
				}
				dst++;
				src += srcbpp;
			},
			width);
			src += srcskip;
			dst += dstskip;
		}
	}
}

static void Blit2to2Key(SDL_BlitInfo *info)
{
	int width = info->d_width;
	int height = info->d_height;
	Uint16 *srcp = (Uint16 *)info->s_pixels;
	int srcskip = info->s_skip;
	Uint16 *dstp = (Uint16 *)info->d_pixels;
	int dstskip = info->d_skip;
	Uint32 ckey = info->src->colorkey;
	Uint32 rgbmask = ~info->src->Amask;

	/* Set up some basic variables */
        srcskip /= 2;
        dstskip /= 2;
	ckey &= rgbmask;

	while ( height-- ) {
		DUFFS_LOOP(
		{
			if ( (*srcp & rgbmask) != ckey ) {
				*dstp = *srcp;
			}
			dstp++;
			srcp++;
		},
		width);
		srcp += srcskip;
		dstp += dstskip;
	}
}

static void BlitNtoNKey(SDL_BlitInfo *info)
{
	int width = info->d_width;
	int height = info->d_height;
	Uint8 *src = info->s_pixels;
	int srcskip = info->s_skip;
	Uint8 *dst = info->d_pixels;
	int dstskip = info->d_skip;
	Uint32 ckey = info->src->colorkey;
	SDL_PixelFormat *srcfmt = info->src;
	SDL_PixelFormat *dstfmt = info->dst;
	int srcbpp = srcfmt->BytesPerPixel;
	int dstbpp = dstfmt->BytesPerPixel;
	unsigned alpha = dstfmt->Amask ? srcfmt->alpha : 0;
	Uint32 rgbmask = ~srcfmt->Amask;

	/* Set up some basic variables */
	ckey &= rgbmask;

	while ( height-- ) {
		DUFFS_LOOP(
		{
		        Uint32 Pixel;
			unsigned sR;
			unsigned sG;
			unsigned sB;
			RETRIEVE_RGB_PIXEL(src, srcbpp, Pixel);
			if ( (Pixel & rgbmask) != ckey ) {
			        RGB_FROM_PIXEL(Pixel, srcfmt, sR, sG, sB);
				ASSEMBLE_RGBA(dst, dstbpp, dstfmt,
					      sR, sG, sB, alpha);
			}
			dst += dstbpp;
			src += srcbpp;
		},
		width);
		src += srcskip;
		dst += dstskip;
	}
}

static void BlitNtoNKeyCopyAlpha(SDL_BlitInfo *info)
{
	int width = info->d_width;
	int height = info->d_height;
	Uint8 *src = info->s_pixels;
	int srcskip = info->s_skip;
	Uint8 *dst = info->d_pixels;
	int dstskip = info->d_skip;
	Uint32 ckey = info->src->colorkey;
	SDL_PixelFormat *srcfmt = info->src;
	SDL_PixelFormat *dstfmt = info->dst;
	Uint32 rgbmask = ~srcfmt->Amask;

	Uint8 srcbpp;
	Uint8 dstbpp;
	Uint32 Pixel;
	unsigned sR, sG, sB, sA;

	/* Set up some basic variables */
	srcbpp = srcfmt->BytesPerPixel;
	dstbpp = dstfmt->BytesPerPixel;
	ckey &= rgbmask;

	/* FIXME: should map alpha to [0..255] correctly! */
	while ( height-- ) {
		DUFFS_LOOP(
		{
			DISEMBLE_RGBA(src, srcbpp, srcfmt, Pixel,
				      sR, sG, sB, sA);
			if ( (Pixel & rgbmask) != ckey ) {
				  ASSEMBLE_RGBA(dst, dstbpp, dstfmt,
						sR, sG, sB, sA);
			}
			dst += dstbpp;
			src += srcbpp;
		},
		width);
		src += srcskip;
		dst += dstskip;
	}
}

/* Normal N to N optimized blitters */
struct blit_table {
	Uint32 srcR, srcG, srcB;
	int dstbpp;
	Uint32 dstR, dstG, dstB;
	Uint32 blit_features;
	void *aux_data;
	SDL_loblit blitfunc;
	enum { NO_ALPHA=1, SET_ALPHA=2, COPY_ALPHA=4 } alpha;
};
static const struct blit_table normal_blit_1[] = {
	/* Default for 8-bit RGB source, an invalid combination */
	{ 0,0,0, 0, 0,0,0, 0, NULL, NULL },
};
static const struct blit_table normal_blit_2[] = {
    { 0x0000F800,0x000007E0,0x0000001F, 4, 0x00FF0000,0x0000FF00,0x000000FF,
      0, NULL, Blit_RGB565_ARGB8888, SET_ALPHA },
    { 0x0000F800,0x000007E0,0x0000001F, 4, 0x000000FF,0x0000FF00,0x00FF0000,
      0, NULL, Blit_RGB565_ABGR8888, SET_ALPHA },
    { 0x0000F800,0x000007E0,0x0000001F, 4, 0xFF000000,0x00FF0000,0x0000FF00,
      0, NULL, Blit_RGB565_RGBA8888, SET_ALPHA },
    { 0x0000F800,0x000007E0,0x0000001F, 4, 0x0000FF00,0x00FF0000,0xFF000000,
      0, NULL, Blit_RGB565_BGRA8888, SET_ALPHA },

    /* Default for 16-bit RGB source, used if no other blitter matches */
    { 0,0,0, 0, 0,0,0, 0, NULL, BlitNtoN, 0 }
};
static const struct blit_table normal_blit_3[] = {
	/* Default for 24-bit RGB source, never optimized */
    { 0,0,0, 0, 0,0,0, 0, NULL, BlitNtoN, 0 }
};
static const struct blit_table normal_blit_4[] = {
	/* Default for 32-bit RGB source, used if no other blitter matches */
	{ 0,0,0, 0, 0,0,0, 0, NULL, BlitNtoN, 0 }
};
static const struct blit_table *normal_blit[] = {
	normal_blit_1, normal_blit_2, normal_blit_3, normal_blit_4
};

/* Mask matches table, or table entry is zero */
#define MASKOK(x, y) (((x) == (y)) || ((y) == 0x00000000))

SDL_loblit SDL_CalculateBlitN(SDL_Surface *surface, int blit_index)
{
	struct private_swaccel *sdata;
	SDL_PixelFormat *srcfmt;
	SDL_PixelFormat *dstfmt;
	const struct blit_table *table;
	int which;
	SDL_loblit blitfun;

	/* Set up data for choosing the blit */
	sdata = surface->map->sw_data;
	srcfmt = surface->format;
	dstfmt = surface->map->dst->format;

	if ( blit_index & 2 ) {
	        /* alpha or alpha+colorkey */
	        return SDL_CalculateAlphaBlit(surface, blit_index);
	}

	/* We don't support destinations less than 8-bits */
	if ( dstfmt->BitsPerPixel < 8 ) {
		return(NULL);
	}
	
	if(blit_index == 1) {
	    /* colorkey blit: Here we don't have too many options, mostly
	       because RLE is the preferred fast way to deal with this.
	       If a particular case turns out to be useful we'll add it. */

	    if(srcfmt->BytesPerPixel == 2
	       && surface->map->identity)
		return Blit2to2Key;
	    else if(dstfmt->BytesPerPixel == 1)
		return BlitNto1Key;
	    else {

		if(srcfmt->Amask && dstfmt->Amask)
		    return BlitNtoNKeyCopyAlpha;
		else
		    return BlitNtoNKey;
	    }
	}

	blitfun = NULL;
	if ( dstfmt->BitsPerPixel == 8 ) {
		/* We assume 8-bit destinations are palettized */
		if ( (srcfmt->BytesPerPixel == 4) &&
		     (srcfmt->Rmask == 0x00FF0000) &&
		     (srcfmt->Gmask == 0x0000FF00) &&
		     (srcfmt->Bmask == 0x000000FF) ) {
			if ( surface->map->table ) {
				blitfun = Blit_RGB888_index8_map;
			}
		} else {
			blitfun = BlitNto1;
		}
	} 
	else 
	{
		/* Now the meat, choose the blitter we want */
		int a_need = NO_ALPHA;
		if(dstfmt->Amask)
		    a_need = srcfmt->Amask ? COPY_ALPHA : SET_ALPHA;
		table = normal_blit[srcfmt->BytesPerPixel-1];
		for ( which=0; table[which].dstbpp; ++which ) {
			if ( MASKOK(srcfmt->Rmask, table[which].srcR) &&
			    MASKOK(srcfmt->Gmask, table[which].srcG) &&
			    MASKOK(srcfmt->Bmask, table[which].srcB) &&
			    MASKOK(dstfmt->Rmask, table[which].dstR) &&
			    MASKOK(dstfmt->Gmask, table[which].dstG) &&
			    MASKOK(dstfmt->Bmask, table[which].dstB) &&
			    dstfmt->BytesPerPixel == table[which].dstbpp &&
			    (a_need & table[which].alpha) == a_need &&
			    ((table[which].blit_features & GetBlitFeatures()) == table[which].blit_features) )
				break;
		}
		sdata->aux_data = table[which].aux_data;
		blitfun = table[which].blitfunc;
	}


	return(blitfun);
}
