/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2012 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Sam Lantinga
    slouken@libsdl.org
*/
#include "SDL_config.h"

/* General keyboard handling code for SDL */

#include "SDL_timer.h"
#include "SDL_events.h"
#include "SDL_events_c.h"
#include "SDL_sysevents.h"


/* Global keystate information */
static Uint8  SDL_KeyState[SDLK_LAST];
static SDLMod SDL_ModState;
int SDL_TranslateUNICODE = 0;

/*
 * jk 991215 - added
 */
struct {
	int firsttime;    /* if we check against the delay or repeat value */
	int delay;        /* the delay before we start repeating */
	int interval;     /* the delay between key repeat events */
	Uint32 timestamp; /* the time the first keydown event occurred */

	SDL_Event evt;    /* the event we are supposed to repeat */
} SDL_KeyRepeat;

/* Global no-lock-keys support */
static Uint8 SDL_NoLockKeys;

#define SDL_NLK_CAPS 0x01
#define SDL_NLK_NUM  0x02

/* Public functions */
int SDL_KeyboardInit(void)
{
	/*const char* env;*/
	SDL_VideoDevice *video = current_video;
	SDL_VideoDevice *this  = current_video;

	/* Set default mode of UNICODE translation */
	SDL_EnableUNICODE(DEFAULT_UNICODE_TRANSLATION);

	/* Initialize the tables */
	SDL_ModState = KMOD_NONE;
	SDL_memset(SDL_KeyState, 0, sizeof(SDL_KeyState));
	video->InitOSKeymap(this);

	SDL_EnableKeyRepeat(0, 0);

	/* Allow environment override to disable special lock-key behavior */
	SDL_NoLockKeys = 0;
	/* Done.  Whew. */
	return(0);
}
void SDL_KeyboardQuit(void)
{
}

/* We lost the keyboard, so post key up messages for all pressed keys */
void SDL_ResetKeyboard(void)
{
	SDL_keysym keysym;
	SDLKey key;

	SDL_memset(&keysym, 0, (sizeof keysym));
	for ( key=SDLK_FIRST; key<SDLK_LAST; ++key ) {
		if ( SDL_KeyState[key] == SDL_PRESSED ) {
			keysym.sym = key;
			SDL_PrivateKeyboard(SDL_RELEASED, &keysym);
		}
	}
	SDL_KeyRepeat.timestamp = 0;
}

int SDL_EnableUNICODE(int enable)
{
	int old_mode;

	old_mode = SDL_TranslateUNICODE;
	if ( enable >= 0 ) {
		SDL_TranslateUNICODE = enable;
	}
	return(old_mode);
}

Uint8 * SDL_GetKeyState (int *numkeys)
{
	if ( numkeys != (int *)0 )
		*numkeys = SDLK_LAST;
	return(SDL_KeyState);
}
SDLMod SDL_GetModState (void)
{
	return(SDL_ModState);
}
void SDL_SetModState (SDLMod modstate)
{
	SDL_ModState = modstate;
}


/* These are global for SDL_eventloop.c */
int SDL_PrivateKeyboard(Uint8 state, SDL_keysym *keysym)
{
	SDL_Event event;
	int posted, repeatable;
	Uint16 modstate;

	SDL_memset(&event, 0, sizeof(event));

	/* Set up the keysym */
	modstate = (Uint16)SDL_ModState;

	repeatable = 0;

	if ( state == SDL_PRESSED ) 
	{
		keysym->mod = (SDLMod)modstate;
		switch (keysym->sym) {
			case SDLK_UNKNOWN:
				break;
			case SDLK_NUMLOCK:
				modstate ^= KMOD_NUM;
				if ( SDL_NoLockKeys & SDL_NLK_NUM )
					break;
				if ( ! (modstate&KMOD_NUM) )
					state = SDL_RELEASED;
				keysym->mod = (SDLMod)modstate;
				break;
			case SDLK_CAPSLOCK:
				modstate ^= KMOD_CAPS;
				if ( SDL_NoLockKeys & SDL_NLK_CAPS )
					break;
				if ( ! (modstate&KMOD_CAPS) )
					state = SDL_RELEASED;
				keysym->mod = (SDLMod)modstate;
				break;
			case SDLK_LCTRL:
				modstate |= KMOD_LCTRL;
				break;
			case SDLK_RCTRL:
				modstate |= KMOD_RCTRL;
				break;
			case SDLK_LSHIFT:
				modstate |= KMOD_LSHIFT;
				break;
			case SDLK_RSHIFT:
				modstate |= KMOD_RSHIFT;
				break;
			case SDLK_LALT:
				modstate |= KMOD_LALT;
				break;
			case SDLK_RALT:
				modstate |= KMOD_RALT;
				break;
			case SDLK_LMETA:
				modstate |= KMOD_LMETA;
				break;
			case SDLK_RMETA:
				modstate |= KMOD_RMETA;
				break;
			case SDLK_MODE:
				modstate |= KMOD_MODE;
				break;
			default:
				repeatable = 1;
				break;
		}
	} 
	else 
	{
		switch (keysym->sym) {
			case SDLK_UNKNOWN:
				break;
			case SDLK_NUMLOCK:
				if ( SDL_NoLockKeys & SDL_NLK_NUM )
					break;
				/* Only send keydown events */
				return(0);
			case SDLK_CAPSLOCK:
				if ( SDL_NoLockKeys & SDL_NLK_CAPS )
					break;
				/* Only send keydown events */
				return(0);
			case SDLK_LCTRL:
				modstate &= ~KMOD_LCTRL;
				break;
			case SDLK_RCTRL:
				modstate &= ~KMOD_RCTRL;
				break;
			case SDLK_LSHIFT:
				modstate &= ~KMOD_LSHIFT;
				break;
			case SDLK_RSHIFT:
				modstate &= ~KMOD_RSHIFT;
				break;
			case SDLK_LALT:
				modstate &= ~KMOD_LALT;
				break;
			case SDLK_RALT:
				modstate &= ~KMOD_RALT;
				break;
			case SDLK_LMETA:
				modstate &= ~KMOD_LMETA;
				break;
			case SDLK_RMETA:
				modstate &= ~KMOD_RMETA;
				break;
			case SDLK_MODE:
				modstate &= ~KMOD_MODE;
				break;
			default:
				break;
		}
		keysym->mod = (SDLMod)modstate;
	}

	/* Figure out what type of event this is */
	switch (state) 
	{
		case SDL_PRESSED:
			event.type = SDL_KEYDOWN;
			break;
		case SDL_RELEASED:
			event.type = SDL_KEYUP;
			/*
			 * jk 991215 - Added
			 */
			if ( SDL_KeyRepeat.timestamp &&
			     SDL_KeyRepeat.evt.key.keysym.sym == keysym->sym ) {
				SDL_KeyRepeat.timestamp = 0;
			}
			break;
		default:
			/* Invalid state -- bail */
			return(0);
	}

	if ( keysym->sym != SDLK_UNKNOWN ) 
	{
		/* Drop events that don't change state */
		if ( SDL_KeyState[keysym->sym] == state ) {
			return(0);
		}

		/* Update internal keyboard state */
		SDL_ModState = (SDLMod)modstate;
		SDL_KeyState[keysym->sym] = state;
	}

	/* Post the event, if desired */
	posted = 0;
	if ( SDL_ProcessEvents[event.type] == SDL_ENABLE ) 
	{
		event.key.state = state;
		event.key.keysym = *keysym;
		/*
		 * jk 991215 - Added
		 */
		if (repeatable && (SDL_KeyRepeat.delay != 0)) {
			SDL_KeyRepeat.evt = event;
			SDL_KeyRepeat.firsttime = 1;
			SDL_KeyRepeat.timestamp=SDL_GetTicks();
		}
		if ( (SDL_EventOK == NULL) || SDL_EventOK(&event) ) {
			posted = 1;
			SDL_PushEvent(&event);
		}
	}
	return(posted);
}

/*
 * jk 991215 - Added
 */
void SDL_CheckKeyRepeat(void)
{
	if ( SDL_KeyRepeat.timestamp ) {
		Uint32 now, interval;

		now = SDL_GetTicks();
		interval = (now - SDL_KeyRepeat.timestamp);
		if ( SDL_KeyRepeat.firsttime ) {
			if ( interval > (Uint32)SDL_KeyRepeat.delay ) {
				SDL_KeyRepeat.timestamp = now;
				SDL_KeyRepeat.firsttime = 0;
			}
		} else {
			if ( interval > (Uint32)SDL_KeyRepeat.interval ) {
				SDL_KeyRepeat.timestamp = now;
				if ( (SDL_EventOK == NULL) || SDL_EventOK(&SDL_KeyRepeat.evt) ) {
					SDL_PushEvent(&SDL_KeyRepeat.evt);
				}
			}
		}
	}
}

int SDL_EnableKeyRepeat(int delay, int interval)
{
	if ( (delay < 0) || (interval < 0) ) {
		return(-1);
	}
	SDL_KeyRepeat.firsttime = 0;
	SDL_KeyRepeat.delay = delay;
	SDL_KeyRepeat.interval = interval;
	SDL_KeyRepeat.timestamp = 0;
	return(0);
}

void SDL_GetKeyRepeat(int *delay, int *interval)
{
	*delay = SDL_KeyRepeat.delay;
	*interval = SDL_KeyRepeat.interval;
}

