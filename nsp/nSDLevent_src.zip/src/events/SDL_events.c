/*
    SDL - Simple DirectMedia Layer
    Copyright (C) 1997-2012 Sam Lantinga

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Sam Lantinga
    slouken@libsdl.org
*/
#include "SDL_config.h"

/* General event handling code for SDL */

#include "SDL.h"
#include "SDL_syswm.h"
#include "SDL_sysevents.h"
#include "SDL_events_c.h"
#include "../timer/SDL_timer_c.h"
#if !SDL_JOYSTICK_DISABLED
#include "../joystick/SDL_joystick_c.h"
#endif

/* Public data -- the event filter */
SDL_EventFilter SDL_EventOK = NULL;
Uint8 SDL_ProcessEvents[SDL_NUMEVENTS];
static Uint32 SDL_eventstate = 0;

/* Private data -- event queue */
#define MAXEVENTS	8
static struct {
	int active;
	int head;
	int tail;
	SDL_Event event[MAXEVENTS];
} SDL_EventQ;


static int SDL_StartEventThread(Uint32 flags)
{
	SDL_EventQ.active = 1;
	return(0);
}


/* Public functions */

void SDL_StopEventLoop(void)
{
	/* Shutdown event handlers */
	SDL_KeyboardQuit();
	SDL_QuitQuit();

	/* Clean out EventQ */
	SDL_EventQ.head = 0;
	SDL_EventQ.tail = 0;
}

/* This function (and associated calls) may be called more than once */
int SDL_StartEventLoop(Uint32 flags)
{
	int retcode;

	/* Clean out the event queue */
	SDL_StopEventLoop();

	/* No filter to start with, process most event types */
	SDL_EventOK = NULL;
	SDL_memset(SDL_ProcessEvents,SDL_ENABLE,sizeof(SDL_ProcessEvents));
	SDL_eventstate = ~0;
	/* It's not save to call SDL_EventState() yet */
	SDL_eventstate &= ~(0x00000001 << SDL_SYSWMEVENT);
	SDL_ProcessEvents[SDL_SYSWMEVENT] = SDL_IGNORE;

	/* Initialize event handlers */
	retcode = 0;
	retcode += SDL_KeyboardInit();
	retcode += SDL_QuitInit();
	if ( retcode < 0 ) {
		/* We don't expect them to fail, but... */
		return(-1);
	}

	/* Create the lock and event thread */
	if ( SDL_StartEventThread(flags) < 0 ) {
		SDL_StopEventLoop();
		return(-1);
	}
	return(0);
}


/* Add an event to the event queue -- called with the queue locked */
static int SDL_AddEvent(SDL_Event *event)
{
	int tail, added;

	tail = (SDL_EventQ.tail+1)%MAXEVENTS;
	if ( tail == SDL_EventQ.head ) {
		/* Overflow, drop event */
		added = 0;
	} else {
		SDL_EventQ.event[SDL_EventQ.tail] = *event;
		SDL_EventQ.tail = tail;
		added = 1;
	}
	return(added);
}

/* Cut an event, and return the next valid spot, or the tail */
/*                           -- called with the queue locked */
static int SDL_CutEvent(int spot)
{
	if ( spot == SDL_EventQ.head ) {
		SDL_EventQ.head = (SDL_EventQ.head+1)%MAXEVENTS;
		return(SDL_EventQ.head);
	} else
	if ( (spot+1)%MAXEVENTS == SDL_EventQ.tail ) {
		SDL_EventQ.tail = spot;
		return(SDL_EventQ.tail);
	} else
	/* We cut the middle -- shift everything over */
	{
		int here, next;

		/* This can probably be optimized with SDL_memcpy() -- careful! */
		if ( --SDL_EventQ.tail < 0 ) {
			SDL_EventQ.tail = MAXEVENTS-1;
		}
		for ( here=spot; here != SDL_EventQ.tail; here = next ) {
			next = (here+1)%MAXEVENTS;
			SDL_EventQ.event[here] = SDL_EventQ.event[next];
		}
		return(spot);
	}
	/* NOTREACHED */
}

/* Lock the event queue, take a peep at it, and unlock it */
int SDL_PeepEvents(SDL_Event *events, int numevents, SDL_eventaction action,
								Uint32 mask)
{
	unsigned short i, used;

	/* Don't look after we've quit */
	if ( ! SDL_EventQ.active ) {
		return(-1);
	}
	
	used = 0;
		
	if ( action == SDL_ADDEVENT ) {
		for ( i=0; i<numevents; ++i ) {
			used += SDL_AddEvent(&events[i]);
		}
	}
	else 
	{
		SDL_Event tmpevent;
		int spot;

		/* If 'events' is NULL, just see if they exist */
		if ( events == NULL ) {
			action = SDL_PEEKEVENT;
			numevents = 1;
			events = &tmpevent;
		}
		spot = SDL_EventQ.head;
		while ((used < numevents)&&(spot != SDL_EventQ.tail)) {
			if ( mask & SDL_EVENTMASK(SDL_EventQ.event[spot].type) ) {
				events[used++] = SDL_EventQ.event[spot];
				if ( action == SDL_GETEVENT ) {
					spot = SDL_CutEvent(spot);
				} else {
					spot = (spot+1)%MAXEVENTS;
				}
			} else {
				spot = (spot+1)%MAXEVENTS;
			}
		}
	}

	return(used);
}

/* Run the system dependent event loops */
void SDL_PumpEvents(void)
{
	SDL_VideoDevice *video = current_video;
	SDL_VideoDevice *this  = current_video;

	/* Get events from the video subsystem */
	video->PumpEvents(this);
	/* Queue pending key-repeat events */
	SDL_CheckKeyRepeat();
}

/* Public functions */

int SDL_PollEvent (SDL_Event *event)
{
	SDL_PumpEvents();

	/* We can't return -1, just return 0 (no event) on error */
	if ( SDL_PeepEvents(event, 1, SDL_GETEVENT, SDL_ALLEVENTS) <= 0 )
		return 0;
	return 1;
}

int SDL_PushEvent(SDL_Event *event)
{
	if ( SDL_PeepEvents(event, 1, SDL_ADDEVENT, 0) <= 0 )
		return -1;
	return 0;
}

void SDL_SetEventFilter (SDL_EventFilter filter)
{
	SDL_Event bitbucket;

	/* Set filter and discard pending events */
	SDL_EventOK = filter;
	while ( SDL_PollEvent(&bitbucket) > 0 );
}

Uint8 SDL_EventState (Uint8 type, int state)
{
	SDL_Event bitbucket;
	Uint8 current_state;

	/* If SDL_ALLEVENTS was specified... */
	if ( type == 0xFF ) {
		current_state = SDL_IGNORE;
		for ( type=0; type<SDL_NUMEVENTS; ++type ) {
			if ( SDL_ProcessEvents[type] != SDL_IGNORE ) {
				current_state = SDL_ENABLE;
			}
			SDL_ProcessEvents[type] = state;
			if ( state == SDL_ENABLE ) {
				SDL_eventstate |= (0x00000001 << (type));
			} else {
				SDL_eventstate &= ~(0x00000001 << (type));
			}
		}
		while ( SDL_PollEvent(&bitbucket) > 0 )
			;
		return(current_state);
	}

	/* Just set the state for one event type */
	current_state = SDL_ProcessEvents[type];
	switch (state) {
		case SDL_IGNORE:
		case SDL_ENABLE:
			/* Set state and discard pending events */
			SDL_ProcessEvents[type] = state;
			if ( state == SDL_ENABLE ) {
				SDL_eventstate |= (0x00000001 << (type));
			} else {
				SDL_eventstate &= ~(0x00000001 << (type));
			}
			while ( SDL_PollEvent(&bitbucket) > 0 )
				;
			break;
		default:
			/* Querying state? */
			break;
	}
	return(current_state);
}
